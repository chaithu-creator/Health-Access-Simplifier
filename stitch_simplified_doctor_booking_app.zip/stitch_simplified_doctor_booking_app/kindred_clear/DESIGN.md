# Design System Document: The Empathetic Path

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Sanctuary"**

This design system rejects the clinical, cold complexity of traditional healthcare software. Instead, it embraces a "Digital Sanctuary" philosophy—creating an environment that feels as calm and dependable as a physical clinic. 

To serve rural and low-literacy users, we move beyond "minimalism" into **Hyper-Clarity**. We break the "template" look by using **Intentional Asymmetry** and **Generous Tonal Depth**. By avoiding rigid grids and opting for oversized, soft-edged containers, we create a UI that feels approachable, not technical. The goal is to guide the user’s eye through a singular, unmistakable path, reducing cognitive load through breathing room and high-contrast editorial hierarchy.

---

## 2. Colors & Surface Architecture
The palette is rooted in nature—specifically the restorative tones of moss, teal, and slate.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section content. Boundaries must be defined solely through background color shifts. 
- Use `surface-container-low` (#f0f4f2) for the base page sections.
- Use `surface-container-lowest` (#ffffff) for primary interactive cards to create a "lifted" feel.
- High-priority calls to action use `primary` (#005e52) to command attention without being aggressive.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine, heavy-weight paper.
*   **Level 0 (Background):** `surface` (#f6faf8) – The foundational canvas.
*   **Level 1 (Sections):** `surface-container` (#ebefec) – Broad areas of content.
*   **Level 2 (Interaction):** `surface-container-lowest` (#ffffff) – High-contrast interactive cards.

### The "Glass & Gradient" Rule
To avoid a flat, "budget" feel, use **Signature Textures**:
*   **Hero Areas:** Apply a subtle linear gradient from `primary` (#005e52) to `primary-container` (#1f786a) at a 45-degree angle.
*   **Floating Navigation:** Use `surface-bright` (#f6faf8) at 85% opacity with a `20px` backdrop-blur to create a "frosted glass" effect for bottom navigation bars.

---

## 3. Typography
We utilize **Lexend** for its exceptional legibility. Its wider character expansion is scientifically proven to aid readers with lower literacy levels or visual impairments.

*   **Display (Editorial Impact):** `display-lg` (3.5rem) should be used sparingly for welcome states. It establishes an authoritative, premium tone.
*   **Headlines (The Navigator):** `headline-md` (1.75rem) serves as the primary wayfinding tool. Ensure headlines are descriptive (e.g., "Find Your Doctor" instead of "Search").
*   **Body (The Guide):** `body-lg` (1rem) is the default for all informational text. Never drop below `body-md` for user-facing instructions to ensure rural accessibility.
*   **Labels:** `label-md` is reserved strictly for non-critical metadata.

---

## 4. Elevation & Depth
In this system, depth is a functional tool for hierarchy, not a decorative flourish.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. The contrast between #ffffff and #f0f4f2 creates a soft, natural lift that is easier on the eyes than harsh shadows.
*   **Ambient Shadows:** For floating CTAs, use a "Cloud Shadow":
    *   Y-Offset: 8px, Blur: 24px, Spread: 0.
    *   Color: `on-surface` (#181d1b) at 6% opacity.
*   **The "Ghost Border" Fallback:** If a container sits on a background of the same color, use a `1.5px` border of `outline-variant` (#bdc9c5) at 30% opacity. Never use 100% opaque outlines.

---

## 5. Components

### Buttons (The "Touch-First" Standard)
All buttons use `rounded-full` (9999px) for a soft, friendly feel.
*   **Primary:** `primary` background with `on-primary` text. Height: 64px (minimum).
*   **Secondary:** `secondary-container` background with `on-secondary-container` text.
*   **Tertiary:** No background; `primary` text weight at Semi-Bold.

### Cards & Lists (The "Anti-Divider" Approach)
*   **Prohibition:** Do not use line dividers between list items.
*   **Solution:** Use vertical white space (1.5rem) or alternating tonal shifts. For booking cards, use `rounded-lg` (2rem) to create a "pillowy" look that feels safe and modern.

### Input Fields
*   **Style:** Filled inputs using `surface-container-high` (#e5e9e7) with a `rounded-md` (1.5rem) corner.
*   **Active State:** The bottom border should animate into a `2px` `primary` line. Labels must remain visible as `label-md` once text is entered.

### Specialized Component: The "Action Shield"
A large, oversized card (120px+ height) used for primary booking flows. It combines a `primary-fixed` (#a0f2e1) background with a large icon and `title-lg` text. This makes the most important action impossible to miss for low-literacy users.

---

## 6. Do's and Don'ts

### Do:
*   **Use Asymmetry:** Place a large header on the left and a floating illustrative element slightly offset to the right to create an editorial feel.
*   **Prioritize Icons:** Pair every major action with a clear, high-contrast icon from a consistent rounded set.
*   **Max Out White Space:** If you think there is enough margin, add 8px more. White space is a "clarity tool" for stressed users.

### Don't:
*   **Don't use "Pure" Black:** Use `on-surface` (#181d1b) for text to maintain a premium, softer look.
*   **Don't stack more than 3 layers:** Too much nesting (surface within surface within surface) creates visual "noise" that confuses users.
*   **Don't use small hit targets:** Every interactive element must have a minimum touch target of 48dp, ideally 56dp for this demographic.